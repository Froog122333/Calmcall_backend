import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import Tts from 'react-native-tts';

export default function App() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');

  const handleCall = async () => {
    if (!phoneNumber || !message) return;

    const statusMessage = `Dialing ${phoneNumber} to say: "${message}"`;
    setResponse(statusMessage);
    Tts.speak(statusMessage);

    try {
      const res = await fetch('http://localhost:5000/api/call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: phoneNumber, prompt: message }),
      });

      const data = await res.json();
      if (data.status === 'success') {
        Tts.speak('The assistant successfully made the call.');
      } else {
        Tts.speak('Call failed. Please try again.');
      }
    } catch (error) {
      console.error(error);
      Tts.speak('Server connection error.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>CalmCall: AI Voice Assistant</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter phone number"
        value={phoneNumber}
        onChangeText={setPhoneNumber}
        keyboardType="phone-pad"
      />
      <TextInput
        style={styles.textarea}
        placeholder="What should the assistant say?"
        value={message}
        onChangeText={setMessage}
        multiline
      />
      <Button title="Call with AI" onPress={handleCall} />
      {response ? <Text style={styles.response}>{response}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#E6F0FA',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    padding: 10,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 10,
  },
  textarea: {
    borderWidth: 1,
    padding: 10,
    borderColor: '#ccc',
    borderRadius: 8,
    height: 100,
    textAlignVertical: 'top',
    marginBottom: 10,
  },
  response: {
    marginTop: 20,
    fontSize: 16,
  },
});
