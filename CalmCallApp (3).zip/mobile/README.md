# CalmCall Mobile App

**CalmCall** is an AI-powered voice assistant designed for people with high anxiety, speech disabilities, or social stress when making phone calls. This mobile app uses text-to-speech (TTS) and integrates with a backend to simulate calls and handle speech for users.

## Features

- Text input for what the AI should say
- Text-to-speech via `react-native-tts`
- Integration with backend API to simulate or place calls
- Designed to be Play Store ready
- Monetization via AdMob and optional premium features (planned)

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   npx pod-install ios
   ```

2. Run the app:
   ```bash
   npx react-native run-android
   ```

3. Make sure the backend server is running on the same network (update the API URL if deploying).

## Revenue Model

- Free version with ads (Google AdMob)
- Optional premium upgrade for unlimited or enhanced features

## Contributing

Pull requests welcome! For major changes, open an issue first to discuss what you would like to change.

## License

MIT
