# CalmCall Backend API

This is the backend server for the CalmCall AI Voice Assistant app. It handles phone call simulations and can be connected to Twilio and OpenAI Whisper for advanced speech and telephony services.

---

## Features

- Simulates voice calls from the AI assistant
- Ready for Twilio voice integration
- Whisper-compatible for voice-to-text transcription
- Designed for deployment on Render, Railway, or similar platforms

---

## File Structure

```
/backend
  └── server.js           # Main Express server
```

---

## Requirements

- Node.js (v16 or newer)
- npm

---

## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/calmcall-backend.git
cd calmcall-backend
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Variables

Create a `.env` file or set environment variables for Twilio and OpenAI (optional):

```
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+11234567890
OPENAI_API_KEY=your_openai_key
```

### 4. Start the Server

```bash
node server.js
```

By default, it runs on `http://localhost:5000`.

---

## API Endpoints

### POST `/api/call`

Simulates making a call.

**Body:**
```json
{
  "number": "+441234567890",
  "prompt": "I'd like to book a morning appointment."
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Call simulated successfully"
}
```

---

## Deployment (Render or Railway)

### Render:
1. Push this repo to GitHub
2. Create a new Web Service on [render.com](https://render.com)
3. Set build command: `npm install`
4. Set start command: `node server.js`
5. Add your environment variables

### Railway:
1. Login to [railway.app](https://railway.app)
2. Create a new project and link this GitHub repo
3. Deploy instantly with environment variables

---

## Security Note

This server is built to be extended. Be sure to:

- Use HTTPS when in production
- Never expose your API keys publicly
- Add request validation for production

---

## License

MIT License
