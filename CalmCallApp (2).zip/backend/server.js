const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/api/call', async (req, res) => {
  const { number, prompt } = req.body;
  console.log(`Simulating AI call to ${number} with message: "${prompt}"`);
  try {
    return res.json({ status: 'success', message: 'Call simulated successfully' });
  } catch (error) {
    console.error('Call error:', error);
    return res.status(500).json({ status: 'error', message: 'Call failed' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
