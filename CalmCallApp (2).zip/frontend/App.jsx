import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export default function AnxietyVoiceAssistantApp() {
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');

  const speakText = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const handleCall = async () => {
    if (!phoneNumber || !message) return;

    const statusMessage = `Dialing ${phoneNumber} to say: "${message}"`;
    setResponse(statusMessage);
    speakText(statusMessage);

    try {
      const res = await fetch('http://localhost:5000/api/call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: phoneNumber, prompt: message })
      });

      const data = await res.json();
      if (data.status === 'success') {
        speakText('The assistant successfully made the call.');
      } else {
        speakText('Call failed. Please try again.');
      }
    } catch (error) {
      console.error(error);
      speakText('Server connection error.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-white p-4 sm:p-6">
      <h1 className="text-3xl font-bold text-center mb-6">CalmCall: AI Voice Assistant</h1>
      <Card className="max-w-xl mx-auto shadow-lg rounded-2xl">
        <CardContent className="space-y-4 p-4 sm:p-6">
          <Input
            placeholder="Enter phone number (e.g., +441234567890)"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
          />
          <Textarea
            placeholder="What should the assistant say?"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="min-h-[100px]"
          />
          <Button onClick={handleCall} disabled={!message || !phoneNumber || isSpeaking}>
            {isSpeaking ? 'Speaking...' : 'Call with AI'}
          </Button>
          {response && (
            <div>
              <h2 className="text-lg font-semibold">Assistant Says:</h2>
              <p className="text-gray-700 mt-1">{response}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
